<img align="right" src="https://github.com/bwmarrin/discordgo/blob/master/docs/img/discordgo.png">

# DiscordGo Examples

These examples demonstrate how to utilize DiscordGo.

Please explore the individual folders and give them a try!

**Join [Discord Gophers](https://discord.gg/0f1SbxBZjYoCtNPP)
Discord chat channel for support.**

