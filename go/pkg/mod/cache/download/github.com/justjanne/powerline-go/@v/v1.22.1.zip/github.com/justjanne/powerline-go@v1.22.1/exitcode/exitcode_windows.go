package exitcode

var Signals = map[int]string{
// We don’t support named errors on Windows
}
